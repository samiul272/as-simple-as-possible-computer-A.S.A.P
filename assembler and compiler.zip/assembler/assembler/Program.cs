﻿/*
Title : Assembler for SAP assignment
Author: Samiul Alam
*/

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace assembler
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader instr = new System.IO.StreamReader("Instructions.txt");
            StreamReader code  = new System.IO.StreamReader("code.txt");
            FileStream bin = File.Open("code.bin", FileMode.Create);
            BinaryWriter binwriter = new System.IO.BinaryWriter(bin);
            List<string[]> opcodes = new List<string[]>();
            bool codeEnded=false;
            int len = 0;
            Int16 addr = 0;
            List<byte> val = new List<byte>();
            binwriter.Write(':');
            int i = 0;
            for (i = 0; i < 16; i++)
            {
                opcodes.Add(instr.ReadLine().Split(','));
            }
            i = 0;
            while (!code.EndOfStream)
            {
                string line = code.ReadLine().ToUpper();
                Console.WriteLine("{0}  :{1}", i.ToString("00"), line);
                if(line =="")
                {
                    i++;
                    continue;
                }
                string inst = line.Split(';')[0];
                if (inst.Contains("END"))
                {
                    codeEnded = true;
                    i++;
                    continue;
                }
                if(inst.Contains("ORG"))
                {
                    binwriter.Write((byte)val.Count);
                    binwriter.Write(BitConverter.GetBytes(addr)[1]);
                    binwriter.Write(BitConverter.GetBytes(addr)[0]);
                    inst = inst.Split(' ')[1];
                    binwriter.Write((byte)0);
                    binwriter.Write(val.ToArray());
                    val.Clear();
                    if (Int16.TryParse(inst,NumberStyles.HexNumber, CultureInfo.InvariantCulture, out addr))
                    {                        
                        binwriter.Write(':');
                        i++;
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("Error in code.txt: line {0} could not be parsed", i);
                    }
                }
                else if (codeEnded)
                {
                    byte db;
                    string[] data = line.Split(',');
                    foreach (var d in data)
                    {
                        if (Byte.TryParse(d,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out db))
                        {
                            val.Add(db);
                        }
                        else
                        {
                            Console.WriteLine("Error in code.txt: line {0} could not be parsed", i);
                        }
                    }
                }
                foreach (var opcode in opcodes)
                {
                    if (inst.Contains(opcode[0].ToUpper()))
                    {                        

                        if (Int32.TryParse(opcode[1], out len))
                        {                            
                            val.Add((byte) opcodes.IndexOf(opcode));
                            if (len == 2)
                            {
                                byte b = 0;
                                inst = inst.Split(',')[1];
                                Byte.TryParse(inst, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out b);
                                val.Add(b);
                            }
                            if (len == 3)
                            {
                                Int16 b = 0;
                                inst = inst.Split(new char[] { '[', ']' })[1];
                                inst = inst.Replace("[", "");
                                inst = inst.Replace("]", "");
                                Int16.TryParse(inst, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out b);
                                byte[] B = BitConverter.GetBytes(b);
                                val.Add(B[0]);
                                val.Add(B[1]);
                            }
                            i++;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Error in Instructions.txt: line {0} could not be parsed", opcodes.IndexOf(opcode));
                        }

                    }
                }

            }
            binwriter.Write((byte) val.Count);
            binwriter.Write(BitConverter.GetBytes(addr)[1]);
            binwriter.Write(BitConverter.GetBytes(addr)[0]);
            binwriter.Write((byte)0);
            binwriter.Write(val.ToArray());
            val.Clear();
            binwriter.Write(':');
            binwriter.Write((byte) 0);
            addr = 0;
            binwriter.Write(addr);
            binwriter.Write((byte)  0x01);
            binwriter.Write((byte)  0xFF);
            Console.WriteLine();
            Console.WriteLine("Compilation ended \n File Size : {0} bytes", bin.Length);
            binwriter.Close();
            Console.ReadLine();

        }
    }
}

