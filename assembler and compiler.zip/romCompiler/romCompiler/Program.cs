﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel;
namespace romCompiler
{

    class Program
    {

        static void Main(string[] args)
        {
            List<string> opcodes = new List<string>();
            List<string> signals = new List<string>();

            #region getstuff
            foreach (var code in Workbook.Worksheets(@"opcode.xlsx"))
            {
                foreach (var row in code.Rows)
                {
                    foreach (var cell in row.Cells)
                    {
                        opcodes.Add(cell.Text);
                    }
                }
            }

            foreach (var sig in Workbook.Worksheets(@"signals.xlsx"))
            {
                foreach (var row in sig.Rows)
                {
                    foreach (var cell in row.Cells)
                    {
                        signals.Add(cell.Text);
                    }
                }
            }

            List<List<string>> instr = new List<List<string>>();
            List<string> actSigs = new List<string>();
            int length = signals.Count();

            for (int i = 0; i < length; i++)
            {
                int j = i + 1;
                actSigs.Clear();
                if (opcodes.ElementAt(i) == "")
                {
                    continue;
                }
                while (signals.ElementAt(j) != "" )
                {
                    actSigs.Add(signals.ElementAt(j));
                    if (j < length-1)
                    {
                        j = j + 1;
                    }
                    else
                        break;

                }
                List<string> tmp = new List<string>(actSigs);
                instr.Add(tmp);

            }

            foreach (var s1 in instr)
            {
                foreach (var item in s1)
                {

                    Console.WriteLine(item);
                }
                Console.WriteLine();

            }

            #endregion

            #region generate words
            String conEn = "NONE,EP,ELT,EA,EB,ES,EIN,EN";
            String conLd = "LHT,LI,LDT,LDA,LDB,LDO,CLD,LM";
            String conMsc = "READ,WRITE,E0,E1,E2,SU,SD,BHE,CP";
            List<string> conWordsEn = conEn.Split(',').ToList();
            List<string> conWordsLd = conLd.Split(',').ToList();
            List<string> conWordsMsc = conMsc.Split(',').ToList();
            int en = 0;
            int ld = 0;
            int misc = 0;
            int word = 0;
            List<List<int>> microinstr = new List<List<int>>();
            List<int> a = new List<int>();
            foreach (var macInstr in instr)
            {
                en = 0;
                ld = 0;
                misc = 0;
                word = 0;
                a.Clear();
                foreach (var tst in macInstr)
                {
                    en = 0;
                    ld = 0;
                    misc = 0;
                    word = 0;

                    List<string> tstates = tst.Split(',').ToList();
                    int n = tstates.Count();
                    for (int i = 0; i < n; i++)
                    {
                        if (conWordsEn.Contains(tstates.ElementAt(i)))
                        {
                            en = conWordsEn.IndexOf(tstates.ElementAt(i));
                        }
                        if (conWordsLd.Contains(tstates.ElementAt(i)))
                        {
                            ld = conWordsLd.IndexOf(tstates.ElementAt(i));
                        }
                        if (conWordsMsc.Contains(tstates.ElementAt(i)))
                        {
                            misc |= 1 << conWordsMsc.IndexOf(tstates.ElementAt(i));
                        }
                    }
                    word = en | ld << 3 | misc << 6;
                    if (macInstr.Last().Equals(tst))
                    {
                        word |= word | 1 << 15;
                    }
                    a.Add(word);
                    word = 0;
                }
                List<int> b = new List<int>(a);
                microinstr.Add(b);
            }
            foreach (var m in microinstr)
            {
                foreach (var n in m)
                {
                    Console.WriteLine("{0:X}", n);
                }
                Console.WriteLine();
            }
            #endregion

            System.IO.StreamWriter LB = new System.IO.StreamWriter("rom1.hex");
            System.IO.StreamWriter HB = new System.IO.StreamWriter("rom2.hex");

            int address = 0;
            int checksumLB = 0;
            int checksumHB = 0;
            foreach (var item in microinstr)
            {


                int n = item.Count()+2;
                LB.Write(":{0}{1}0003948", n.ToString("X2"), address.ToString("X3"));
                HB.Write(":{0}{1}0000040", n.ToString("X2"), address.ToString("X3"));
                checksumLB = n + ((address << 4) & 0xFF) + 0x39 + 0x48;
                checksumHB = n + ((address << 4) & 0xFF) + 0x40;

                address++;
                foreach (var item2 in item)
                {
                    UInt16 bt = (UInt16)item2;
                    byte[] bytes = BitConverter.GetBytes(bt);
                    LB.Write("{0}", bytes.ElementAt(0).ToString("X2"));
                    HB.Write("{0}", bytes.ElementAt(1).ToString("X2"));
                    checksumLB += (int)bytes.ElementAt(0);
                    checksumHB += (int)bytes.ElementAt(1);
                }

                checksumLB = (int)BitConverter.GetBytes(-checksumLB).ElementAt(0);
                checksumHB = (int)BitConverter.GetBytes(-checksumHB).ElementAt(0);
                LB.Write("{0}", checksumLB.ToString("X2"));
                HB.Write("{0}", checksumHB.ToString("X2"));
                checksumLB = 0;
                checksumHB = 0;
                LB.WriteLine();
                HB.WriteLine();
            }

            //LB.WriteLine(":0401900039480000EA");
            //HB.WriteLine(":04019000004040C02B");            
            LB.WriteLine(":04010000394800007A");
            HB.WriteLine(":04010000004040C0BB");
            LB.Write(":00000001FF");
            HB.Write(":00000001FF");
            LB.Close();
            HB.Close();
            Console.ReadLine();

        }
    }
}






